package exe7_prob5_Generic_Count_Method_Strings;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int input = Integer.parseInt(scanner.nextLine());
        Box<Double> box = new Box<>();
        for (int i = 0; i < input; i++) {
            box.add(Double.parseDouble(scanner.nextLine()));
        }
        String elementToCompare = scanner.nextLine();
        System.out.println(box.countOfGreaterElements(Double.parseDouble(elementToCompare)));
    }
}
