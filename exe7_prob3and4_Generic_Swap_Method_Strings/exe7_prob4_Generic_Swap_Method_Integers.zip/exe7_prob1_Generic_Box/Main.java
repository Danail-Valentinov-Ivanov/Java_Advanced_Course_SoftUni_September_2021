package exe7_prob1_Generic_Box;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int input = Integer.parseInt(scanner.nextLine());
        Box<Integer> box = new Box<>();
        for (int i = 0; i < input; i++) {
            box.add(Integer.parseInt(scanner.nextLine()));
        }
        String[] arrayStr = scanner.nextLine().split(" ");
        int firstIndex = Integer.parseInt(arrayStr[0]);
        int secondIndex = Integer.parseInt(arrayStr[1]);
        box.swap(firstIndex, secondIndex);
        System.out.println(box);
    }
}
